import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:immunowarriors/domain/providers/auth_provider.dart';
import 'package:immunowarriors/domain/entities/agent_pathogene.dart'; // Importez vos entités
import 'package:immunowarriors/infrastructure/repositories/firestore_service.dart'; // Importez le service Firestore

class TemporaryHomeScreen extends ConsumerWidget {
  const TemporaryHomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final Color primaryColor = Color(0xFF1A1A1A); // Presque noir
    final Color accentColor = Color(0xFF00C853); // Vert vif
    final firestoreService = ref.read(firestoreServiceProvider); // Accédez à votre service Firestore

    return Scaffold(
      backgroundColor: primaryColor,
      appBar: AppBar(
        title: Text(
          'ImmunoWarriors - Quartier Général',
          style: TextStyle(
            color: accentColor,
            fontWeight: FontWeight.bold,
            fontSize: 22,
            letterSpacing: 1.2,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(
            icon: Icon(Icons.logout, color: accentColor),
            onPressed: () async {
              await ref.read(firebaseAuthProvider).signOut();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Déconnexion réussie. Accès révoqué.')),
              );
            },
            tooltip: 'Déconnexion',
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.security,
              size: 80,
              color: accentColor,
            ),
            const SizedBox(height: 30),
            Text(
              'Bienvenue, Cyber-Guerrier !',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 10),
            Text(
              'Prêt pour le déploiement ?',
              style: TextStyle(
                fontSize: 16,
                color: Colors.white70,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 50),
            // Bouton pour ajouter un agent pathogène de test
            ElevatedButton.icon(
              onPressed: () async {
                // Créer un nouvel agent pathogène (Virus)
                final testVirus = Virus(
                  id: 'virus_${DateTime.now().millisecondsSinceEpoch}',
                  nom: 'Grippe Numérique',
                  pointsDeVie: 100,
                  attaque: 15,
                  defense: 5,
                  recompense: {'energie': 10, 'proteines': 5},
                  tauxDeMutation: 0.2,
                );

                try {
                  // Utiliser le service Firestore pour ajouter le virus à la collection 'agents_pathogenes'
                  await firestoreService.addDocument(
                    'agents_pathogenes', // Nom de la collection dans Firestore
                    testVirus.toMap(),
                    docId: testVirus.id, // Utiliser l'ID de l'objet comme ID de document Firestore
                  );
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Agent Pathogène ajouté à la base de données !')),
                    );
                  }
                } catch (e) {
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Erreur lors de l\'ajout de l\'agent: $e')),
                    );
                  }
                }
              },
              icon: Icon(Icons.add_box, color: primaryColor),
              label: const Text('Déployer un Agent Pathogène'),
              style: ElevatedButton.styleFrom(
                backgroundColor: accentColor,
                foregroundColor: primaryColor,
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                textStyle: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'Agents Pathogènes Déployés (Test):',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            // Utilisation d'un StreamBuilder pour écouter les changements dans Firestore
            Expanded(
              child: StreamBuilder<List<Map<String, dynamic>>>(
                stream: firestoreService.getCollectionStream('agents_pathogenes'),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator(color: accentColor));
                  }
                  if (snapshot.hasError) {
                    return Center(child: Text('Erreur de chargement des données: ${snapshot.error}', style: TextStyle(color: Colors.red)));
                  }
                  if (!snapshot.hasData || snapshot.data!.isEmpty) {
                    return Center(child: Text('Aucun agent pathogène trouvé.', style: TextStyle(color: Colors.white70)));
                  }

                  final agentsData = snapshot.data!;
                  return ListView.builder(
                    itemCount: agentsData.length,
                    itemBuilder: (context, index) {
                      // Tente de désérialiser la Map en objet AgentPathogene
                      try {
                        final agent = AgentPathogene.fromMap(agentsData[index]);
                        return Card(
                          margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                          color: Color(0xFF2C2C2C), // Couleur de carte sombre
                          child: Padding(
                            padding: const EdgeInsets.all(12.0),
                            child: Row(
                              children: [
                                Icon(Icons.bug_report, color: accentColor),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Nom: ${agent.nom} (${agent.type})',
                                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                                      ),
                                      Text('PV: ${agent.pointsDeVie}, Att: ${agent.attaque}, Def: ${agent.defense}',
                                          style: TextStyle(color: Colors.white70, fontSize: 14)),
                                      // Afficher les propriétés spécifiques aux sous-classes
                                      if (agent is Virus)
                                        Text('Mutation: ${agent.tauxDeMutation}', style: TextStyle(color: Colors.white54)),
                                      if (agent is Bactery)
                                        Text('Résistance: ${agent.resistanceAntibiotique}', style: TextStyle(color: Colors.white54)),
                                      if (agent is Fungus)
                                        Text('Toxicité: ${agent.toxicite}', style: TextStyle(color: Colors.white54)),
                                    ],
                                  ),
                                ),
                                IconButton(
                                  icon: Icon(Icons.delete, color: Colors.redAccent),
                                  onPressed: () async {
                                    await firestoreService.deleteDocument('agents_pathogenes', agent.id);
                                    if (context.mounted) {
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(content: Text('${agent.nom} supprimé.')),
                                      );
                                    }
                                  },
                                ),
                              ],
                            ),
                          ),
                        );
                      } catch (e) {
                        // Gérer les erreurs de désérialisation
                        return Card(
                          margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                          color: Color(0xFF2C2C2C),
                          child: Padding(
                            padding: const EdgeInsets.all(12.0),
                            child: Text(
                              'Erreur de données pour un agent: $e',
                              style: TextStyle(color: Colors.redAccent),
                            ),
                          ),
                        );
                      }
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}