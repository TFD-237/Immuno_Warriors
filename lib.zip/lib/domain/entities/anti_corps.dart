// lib/domain/entities/anti_corps.dart

import 'package:flutter/foundation.dart'; // Pour @required si nécessaire

abstract class AntiCorps {
  final String id;
  final String nom;
  final String type; // Ex: 'CelluleT', 'CelluleB', 'Macrophage'
  int pointsDeVie;
  final int attaque;
  final int defense;
  final Map<String, int> coutProduction; // Ex: {'energie': 100, 'proteines': 50}

  AntiCorps({
    required this.id,
    required this.nom,
    required this.type,
    required this.pointsDeVie,
    required this.attaque,
    required this.defense,
    required this.coutProduction,
  });

  // Convertit l'objet AntiCorps en Map pour Firestore
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nom': nom,
      'type': type,
      'pointsDeVie': pointsDeVie,
      'attaque': attaque,
      'defense': defense,
      'coutProduction': coutProduction,
    };
  }

  // Méthode factory pour créer un AntiCorps à partir d'un Map Firestore
  factory AntiCorps.fromMap(Map<String, dynamic> map) {
    // Cette méthode doit instancier la bonne sous-classe
    switch (map['type']) {
      case 'Cellule T': // Assurez-vous que le type correspond à celui défini dans la sous-classe
        return CelluleT.fromMap(map);
      case 'Macrophage':
        return Macrophage.fromMap(map);
    // Ajoutez d'autres cas si vous avez plus de sous-classes
      default:
        throw Exception('Type d\'AntiCorps inconnu : ${map['type']}');
    }
  }

  // Méthodes de base
  void subirDegats(int degats) {
    pointsDeVie -= degats;
    if (pointsDeVie < 0) pointsDeVie = 0;
    print('$nom a subi $degats dégâts. PV restants: $pointsDeVie');
  }

  int attaquer() {
    return attaque;
  }

  bool estDetruit() => pointsDeVie <= 0;
}

// Classe concrète pour une Cellule T
class CelluleT extends AntiCorps {
  final double bonusCritique; // Chance de coup critique

  CelluleT({
    required String id,
    required String nom,
    required int pointsDeVie,
    required int attaque,
    required int defense,
    required Map<String, int> coutProduction,
    this.bonusCritique = 0.15, // 15% de chance de coup critique
  }) : super(
    id: id,
    nom: nom,
    type: 'Cellule T',
    pointsDeVie: pointsDeVie,
    attaque: attaque,
    defense: defense,
    coutProduction: coutProduction,
  );

  // Constructeur factory pour créer une CelluleT à partir d'un Map
  factory CelluleT.fromMap(Map<String, dynamic> map) {
    return CelluleT(
      id: map['id'] as String,
      nom: map['nom'] as String,
      pointsDeVie: map['pointsDeVie'] as int,
      attaque: map['attaque'] as int,
      defense: map['defense'] as int,
      coutProduction: Map<String, int>.from(map['coutProduction'] as Map),
      bonusCritique: map['bonusCritique'] as double,
    );
  }

  @override
  Map<String, dynamic> toMap() {
    return {
      ...super.toMap(), // Inclut les propriétés de la classe parente
      'bonusCritique': bonusCritique,
    };
  }

  @override
  int attaquer() {
    int degats = super.attaquer();
    if (DateTime.now().microsecondsSinceEpoch % 100 < (bonusCritique * 100).toInt()) {
      print('$nom (Cellule T) inflige un coup critique !');
      return degats * 2;
    }
    print('$nom (Cellule T) attaque.');
    return degats;
  }
}

// Classe concrète pour un Macrophage
class Macrophage extends AntiCorps {
  final int soinParTour; // Capacité de soin autonome

  Macrophage({
    required String id,
    required String nom,
    required int pointsDeVie,
    required int attaque,
    required int defense,
    required Map<String, int> coutProduction,
    this.soinParTour = 5,
  }) : super(
    id: id,
    nom: nom,
    type: 'Macrophage',
    pointsDeVie: pointsDeVie,
    attaque: attaque,
    defense: defense,
    coutProduction: coutProduction,
  );

  // Constructeur factory pour créer un Macrophage à partir d'un Map
  factory Macrophage.fromMap(Map<String, dynamic> map) {
    return Macrophage(
      id: map['id'] as String,
      nom: map['nom'] as String,
      pointsDeVie: map['pointsDeVie'] as int,
      attaque: map['attaque'] as int,
      defense: map['defense'] as int,
      coutProduction: Map<String, int>.from(map['coutProduction'] as Map),
      soinParTour: map['soinParTour'] as int,
    );
  }

  @override
  Map<String, dynamic> toMap() {
    return {
      ...super.toMap(),
      'soinParTour': soinParTour,
    };
  }

  void soigner() {
    pointsDeVie += soinParTour;
    print('$nom (Macrophage) se soigne de $soinParTour PV. PV actuels: $pointsDeVie');
  }

  @override
  int attaquer() {
    print('$nom (Macrophage) engloutit l\'ennemi !');
    return super.attaquer();
  }
}