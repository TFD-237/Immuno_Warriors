/// Stocke les signatures des pathogènes vaincus et confère des bonus.
class MemoireImmunitaire {
  // Un Map pour stocker les signatures et compter combien de fois un pathogène a été vaincu,
  // ou juste un Set<String> si seule la présence de la signature suffit.
  final Map<String, int> signaturesPathogenesVaincus; // Clé: ID/Type de pathogène, Valeur: Compteur

  MemoireImmunitaire({
    Map<String, int>? signaturesPathogenesVaincus,
  }) : signaturesPathogenesVaincus = signaturesPathogenesVaincus ?? {};

  /// Enregistre une signature de pathogène après une victoire.
  void enregistrerSignature(String pathogeneId) {
    signaturesPathogenesVaincus[pathogeneId] = (signaturesPathogenesVaincus[pathogeneId] ?? 0) + 1;
    print('Signature de $pathogeneId enregistrée dans la mémoire immunitaire.');
  }

  /// Vérifie si une signature est connue.
  bool estSignatureConnue(String pathogeneId) {
    return signaturesPathogenesVaincus.containsKey(pathogeneId);
  }

  /// Calcule et retourne les bonus basés sur la mémoire immunitaire.
  /// La logique exacte des bonus sera implémentée dans les use cases (ex: combat).
  Map<String, dynamic> getBonus() {
    // Exemple très simple:
    int bonusDegatsContreVirus = signaturesPathogenesVaincus['Virus'] ?? 0;
    // Logique plus complexe: des bonus progressifs, des bonus pour des combinaisons, etc.
    return {
      'bonusDegatsContreVirus': bonusDegatsContreVirus * 0.05, // 5% de bonus par virus vaincu
    };
  }

  Map<String, dynamic> toJson() {
    return {
      'signaturesPathogenesVaincus': signaturesPathogenesVaincus,
    };
  }

  factory MemoireImmunitaire.fromJson(Map<String, dynamic> json) {
    return MemoireImmunitaire(
      signaturesPathogenesVaincus: Map<String, int>.from(json['signaturesPathogenesVaincus'] as Map),
    );
  }

  @override
  String toString() {
    return 'Mémoire Immunitaire: ${signaturesPathogenesVaincus.length} signatures connues.';
  }
}