/// Gère l'état du Laboratoire R&D du joueur.
class LaboratoireRecherche {
  int pointsDeRecherche;
  final Map<String, bool> technologiesDebloquees; // Clé: nom_tech, Valeur: true/false

  LaboratoireRecherche({
    this.pointsDeRecherche = 0,
    Map<String, bool>? technologiesDebloquees,
  }) : technologiesDebloquees = technologiesDebloquees ?? {};

  /// Tente de débloquer une technologie.
  /// Retourne true si la technologie a été débloquée avec succès, false sinon.
  bool debloquerTechnologie(String nomTechnologie, int coutPoints) {
    if (technologiesDebloquees.containsKey(nomTechnologie)) {
      print('Technologie "$nomTechnologie" déjà débloquée.');
      return false;
    }
    if (pointsDeRecherche >= coutPoints) {
      pointsDeRecherche -= coutPoints;
      technologiesDebloquees[nomTechnologie] = true;
      print('Technologie "$nomTechnologie" débloquée pour $coutPoints points de recherche. Restant: $pointsDeRecherche.');
      return true;
    } else {
      print('Points de recherche insuffisants pour "$nomTechnologie". Nécessaire: $coutPoints, Actuel: $pointsDeRecherche.');
      return false;
    }
  }

  /// Ajoute des points de recherche.
  void ajouterPointsDeRecherche(int montant) {
    pointsDeRecherche += montant;
    print('$montant points de recherche ajoutés. Total: $pointsDeRecherche.');
  }

  Map<String, dynamic> toJson() {
    return {
      'pointsDeRecherche': pointsDeRecherche,
      'technologiesDebloquees': technologiesDebloquees,
    };
  }

  factory LaboratoireRecherche.fromJson(Map<String, dynamic> json) {
    return LaboratoireRecherche(
      pointsDeRecherche: json['pointsDeRecherche'] as int,
      technologiesDebloquees: Map<String, bool>.from(json['technologiesDebloquees'] as Map),
    );
  }

  @override
  String toString() {
    return 'Laboratoire R&D: $pointsDeRecherche PR, ${technologiesDebloquees.length} techs débloquées.';
  }
}